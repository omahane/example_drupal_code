# Purpose
This module provides custom functionality to support the benefit office (VBA facility)  content type. It includes the following functionality:
- Validation and form clean-up for adding or removing a page banner
- The appending of facility service information to the facility view

